# FoodBridge 🍃

FoodBridge is a food donation platform front-end demo that connects food donors with NGOs and volunteers.

## Features

- Home page with project overview and statistics
- Available food donation cards
- Food donation submission form
- Demo login roles: Donor, NGO, Volunteer, and Admin
- Donor dashboard
- Admin donation status controls
- Responsive layout for smaller screens

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a web browser.

No build tools are required.

## Important notes

- This version is a **front-end demonstration**.
- Donation records and the demo login state are stored in the browser's `localStorage`.
- Data is not shared between different browsers or devices.
- The login form is not secure authentication. Do not use real passwords or sensitive information.
- A PHP + MySQL backend, secure authentication, and server-side validation are not included in this version.

## GitHub Pages

To publish the front-end demo:

1. Push these files to a GitHub repository.
2. Open the repository's **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the `main` branch and `/ (root)` folder, then save.
5. Wait for GitHub Pages to publish the site.

## Project structure

```text
FoodBridge/
├── index.html
├── README.md
├── .gitignore
└── LICENSE
```

## Project

**FoodBridge — Share Food. Spread Happiness.**
